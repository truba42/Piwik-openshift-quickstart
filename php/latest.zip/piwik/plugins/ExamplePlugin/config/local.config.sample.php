<?php
return array(
	'id' => 'Example',
	'name' => 'ExamplePlugin',
	'description' => 'This is an example',
);
